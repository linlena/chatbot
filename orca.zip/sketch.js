let data; 
let inp;
let button; 
let answer = ""; 

// load the JSON file
function preload() {
  data = loadJSON("data.json");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  // input field
  inp = createInput("");
  inp.size(width/2, 40);
  inp.position(width/4, height/4);
  
  // button
  button = createButton("enter");
  button.size(50, 30);
  button.position(width/2 - 25, height/4 + 60);
  button.mousePressed(answerMe);
  
  console.log(data);
}

function keyPressed(){
  if(keyCode==ENTER){
    answerMe();
  }
}

function draw() {
  background("PaleVioletRed");
  fill("black");
  textSize(20);
  textAlign(CENTER);
  text("Ask me about orcas!", width/2, height/4 - 50);
  
  fill("black");
  textSize(10);
  text(answer, width/2, height/4 + 120);
}

function answerMe() {
  // prepare input string for analysis
  let inputStr = inp.value();
  inputStr = inputStr.toLowerCase();
  
  loop1: for (let i = 0; i < data.brain.length; i++) {
    loop2: for (let j = 0; j < data.brain[i].triggers.length; j++) {
      if (inputStr.indexOf(data.brain[i].triggers[j]) != -1) {
        answer = random(data.brain[i].responses);
        break loop1;
      } else {
        answer = random(data.catchall);
      }
    }  
  }
  // clears input field
  inp.value("");
}